export const environment = {
    APIURL:'http://localhost:4454'
};
