import { Component, OnInit, OnDestroy } from '@angular/core';
import { WeatherCitiesService } from '../../Services/weather-cities.service';
import { Icity } from 'src/app/Models/icity';
import { Subscription } from 'rxjs';
import { Event } from '@angular/router';

@Component({
  selector: 'app-cities-list',
  templateUrl: './cities-list.component.html',
  styleUrls: ['./cities-list.component.css']
})
export class CitiesListComponent implements OnInit, OnDestroy {
  cities!: Icity[];
  citiesSusbcribtions = new Subscription();
  // searchTerm !: number;
  // searchCity !: Icity;
  cityName: string = '';
  cityData !: Icity[];
  constructor(private weatherService: WeatherCitiesService) {

  }

  ngOnInit(): void {
    this.getAllData();

  }
  getAllData() {
    this.citiesSusbcribtions.add(this.weatherService.getAllCities().subscribe((data) => {
      console.log(data);
      this.cities = data;
    },
    (error) => {
      console.error('Error occured to get all cities:', error);
    }
    ))
  }
  // search(): void {
  //   this.weatherService.getSpecificCity(this.searchTerm).subscribe((data: any) => {
  //     this.searchCity = data;
  //     console.log(data);
  //   });
  // }
  search() {
    if (this.cityName) {
      this.weatherService.getCityName(this.cityName).subscribe(
        (response) => {
          console.log(response)
          // this.cityData = response.data;
          this.cityData = Array.isArray(response) ? response : [];
        },
        (error) => {
          console.error('Error searching for city:', error);
        }
      );
    }
  }

  ngOnDestroy(): void {
    this.citiesSusbcribtions.unsubscribe();

  }
}
