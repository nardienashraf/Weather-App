export interface Iforecast {
    date:string,
    temperatureCelsius:number,
    temperatureFahrenheit:number,
    humidity:number
}
